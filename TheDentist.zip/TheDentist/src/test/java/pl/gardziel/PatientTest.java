package pl.gardziel;

public class PatientTest {
    @Test
    void newlyCreatedPatientShouldNotBeActive() {

        //given
        Patient newPatient = new Patient();

        //then
        assertFalse(newAccount.isActive());
        assertThat(newAccount.isActive(), equalTo(false));
        assertThat(newAccount.isActive(), is(false));

    }

    @Test
    void activatedPaitientShouldHaveActiveFlagSet() {

        //given
        Patient newPatient = new Patient();

        //when
        newAccount.activate();

        //then
        assertTrue(newPatient.isActive());
        assertThat(newPatient.isActive(), equalTo(true));

    }

    @Test
    void newlyCreatedPatientShouldNotHaveDefaultDeliveryAddressSet() {

        //given
        Patient newPatient = new Patient();
        //when
        Address address = account.getDefaultDeliveryAddress();

        //then
        assertNull(address);
        assertThat(address, nullValue());

    }

    @Test
    void defaultDeliveryAddressShouldNotBeNullAfterBeingSet() {

        //given
        Address address = new Address("Krakowska", "67c");
        Patient newPatient = new Patient();
        patient.setDefaultDeliveryAddress(address);

        //when
        Address defaultAddress = account.getDefaultDeliveryAddress();

        //then
        assertNotNull(defaultAddress);
        assertThat(defaultAddress, is(notNullValue()));

    }

    @RepeatedTest(25)
    void newPatientWithNotNullAddressShouldBeActive() {

        //given
        Address address = new Address("Puławska", "46/6");

        //when
        Patient patient = new Patient(address);

        //then
        assumingThat(address != null, () -> {
            assertTrue(patient.isActive());
        });

    }

    @Test
    void invalidEmailShouldThrowException() {

        //given
        Account account = new Account();

        //when
        //then
        assertThrows(IllegalArgumentException.class, () -> account.setEmail("wrongEmail"));

    }

    @Test
    void validEmailShouldBeSet() {
        //given
        Patient newPatient = new Patient();


        //when
        patient.setEmail("kontakt@denist.pl");

        //then
        assertThat(patient.getEmail(), is("kontakt@denist.pl"));
    }


}
