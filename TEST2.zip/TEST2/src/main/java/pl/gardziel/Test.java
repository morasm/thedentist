package pl.gardziel;

public @interface Test {
}
